<?php
session_start();

if (!isset($_SESSION["user"])) {
   header("Location: exweb.php");
   exit();
}

// Check the user's role
$role = $_SESSION["user"]["role"];

// Redirect based on the role
if ($role === "admin") {
    header("Location: admin.php");
    exit();
} elseif ($role === "teacher") {
    header("Location: teachers.php");
    exit();
} elseif ($role === "student") {
    header("Location: students.php");
    exit();
} elseif ($role === "ICTteacher") {
    header("Location: ictteacher.php");
    exit();
} elseif ($role === "STEMteacher") {
    header("Location: stemteacher.php");
    exit();
} elseif ($role === "GASteacher") {
    header("Location: gasteacher.php");
    exit();
} elseif ($role === "ABMteacher") {
    header("Location: abmteacher.php");
    exit();
} elseif ($role === "HUMMSteacher") {
    header("Location: hummsteacher.php");
    exit();
} elseif ($role === "ICT") {
    header("Location: ictstudent.php");
    exit();
} elseif ($role === "STEM") {
    header("Location: stemstudent.php");
    exit();
} elseif ($role === "GAS") {
    header("Location: gasstudent.php");
    exit();
} elseif ($role === "ABM") {
    header("Location: abmstudent.php");
    exit();
} elseif ($role === "Humms") {
    header("Location: hummsstudent.php");
    exit();
} elseif ($role === "ICTteacher12") {
    header("Location: ictteacher12.php");
    exit();
} elseif ($role === "STEMteacher12") {
    header("Location: stemteacher12.php");
    exit();
} elseif ($role === "GASteacher12") {
    header("Location: gasteacher12.php");
    exit();
} elseif ($role === "ABMteacher12") {
    header("Location: abmteacher12.php");
    exit();
} elseif ($role === "HUMMSteacher12") {
    header("Location: hummsteacher12.php");
    exit();
} elseif ($role === "ICT12") {
    header("Location: ictstudent12.php");
    exit();
} elseif ($role === "STEM12") {
    header("Location: stemstudent12.php");
    exit();
} elseif ($role === "GAS12") {
    header("Location: gasstudent12.php");
    exit();
} elseif ($role === "ABM12") {
    header("Location: abmstudent12.php");
    exit();
} elseif ($role === "Humms12") {
    header("Location: hummsstudent12.php");
    exit();
}

// Default redirect if the role is not recognized
header("Location: index.php");
exit();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>User Dashboard</title>
</head>
<body>
    <div class="container">
        <h1>Welcome to SJaCS'S Aleph Project</h1>
        <a href="logout.php" class="btn btn-warning">Logout</a>
    </div>
</body>
</html>
